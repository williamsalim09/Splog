import { useState } from "react";

const SongDetailsCard = (props) => {
  return (
    <div>
      <div className="fixed w-full h-full left-0 right-0 top-0 bottom-0 m-auto bg-black opacity-80"></div>
      <div className="fixed w-[30rem] h-[42rem] left-0 right-0 top-0 bottom-0 m-auto bg-gradient-to-b from-amber-500 to-white">
        <img src={props.albumCover} alt="album cover" className="p-5" />
        <div className="text-black px-5 pb-5">
          <p className="text-2xl font-bold font-sans truncate">{props.songTitle}</p>
          <p className="font-medium font-sans">{props.artistName}</p>
          <div className="flex">
            {props.songFeatures != null ? 
              [
                <div className="w-1/2">
                  <p>Acousticness: {props.songFeatures.acousticness}</p>
                  <p>Danceability: {props.songFeatures.danceability}</p>
                  <p>Energy: {props.songFeatures.energy}</p>
                  <p>Instrumentalness: {props.songFeatures.instrumentalness}</p>
                </div>,
                <div className="w-1/2">
                  <p>Liveness: {props.songFeatures.liveness}</p>
                  <p>Loudness: {props.songFeatures.loudness}</p>
                  <p>Speechiness: {props.songFeatures.speechiness}</p>
                  <p>Valence: {props.songFeatures.valence}</p>
                </div>
              ] : <p>No details</p>
            }
          </div>
          <p onClick={props.onStopShowingDetails}>Cancel</p>
        </div>
      </div>
    </div>
  )
}

export default SongDetailsCard;