import { useEffect, useState } from "react";

import TimeFrameSelector from "../common/TimeFrameSelector";
import SongCard from "./SongCard";
import SongBanner from "./SongBanner";

const TopSongs = (props) => {
  const [songsData, setSongsData] = useState([]);

  useEffect(() => {
    setSongsData(props.songsData)
  }, [props])

  if (songsData.length === 0 || songsData == null) {
    return (
      <div></div>
    )
  }

  const getShortTermSongsData = (data) => {
    setSongsData(data)
  }

  const getMediumTermSongsData = (data) => {
    setSongsData(data)
  }

  const getLongTermSongsData = (data) => {
    setSongsData(data)
  }

  return (
    <>
      <SongBanner></SongBanner>
      <div className="w-3/5 mx-auto pb-10">
        <div className="bg-amber-500 flex justify-between px-4">
          <p className="text-black text-3xl font-bold font-sans">Top Songs</p>
          <div className="flex text-black font-medium font-sans">
            <TimeFrameSelector termTitle={"Last Month"} term={"short"} type={"song"} onGetShortTermSongsData = {getShortTermSongsData}/>
            <TimeFrameSelector termTitle={"Last 6 Months"} term={"medium"} type={"song"} onGetMediumTermSongsData = {getMediumTermSongsData}/>
            <TimeFrameSelector termTitle={"All Time"} term={"long"} type={"song"} onGetLongTermSongsData = {getLongTermSongsData}/>
          </div>
        </div>
        <p className="text-neutral-300 py-1 font-medium font-sans">Your top songs from the past 4 weeks</p>
        <div className="grid grid-cols-5 gap-4">
          {songsData.items.map(data =>
            <SongCard
              key={data.id}
              songId={data.id}
              albumCover={data.album.images[0].url}
              title={data.name}
              artist={data.artists[0].name}
            />)}
        </div>
      </div>
    </>
  )
}

export default TopSongs;