import { useEffect, useState } from "react";

import TimeFrameSelector from "../common/TimeFrameSelector";
import ArtistCard from "./ArtistCard";
import ArtistBanner from "./ArtistBanner";

const TopArtists = (props) => {
  const [artistsData, setArtistsData] = useState([]);

  useEffect(() => {
    setArtistsData(props.artistsData)
  }, [props])

  const getShortTermArtistsData = (data) => {
    setArtistsData(data)
  }

  const getMediumTermArtistsData = (data) => {
    setArtistsData(data)
  }

  const getLongTermArtistsData = (data) => {
    setArtistsData(data)
  }

  if (artistsData.length === 0 || artistsData == null) {
    return (
      <div></div>
    )
  }

  return (
    <>
      <ArtistBanner></ArtistBanner>
      <div className="w-3/5 mx-auto pb-10">
        <div className="bg-amber-500 flex justify-between px-4">
          <p className="text-black text-3xl font-bold">Top Artists</p>
          <div className="flex text-black font-medium">
            <TimeFrameSelector termTitle={"Last Month"} term={"short"} type={"artist"} onGetShortTermArtistsData={getShortTermArtistsData}/>
            <TimeFrameSelector termTitle={"Last 6 Month"} term={"medium"} type={"artist"} onGetMediumTermArtistsData={getMediumTermArtistsData}/>
            <TimeFrameSelector termTitle={"All Time"} term={"long"} type={"artist"} onGetLongTermArtistsData={getLongTermArtistsData}/>
          </div>
        </div>
        <p className="text-neutral-300 py-1 font-medium">Your top artists from the past 4 weeks</p>
        <div className="grid grid-cols-5 gap-4">
          {artistsData.items.map(data => 
            <ArtistCard
              key={data.id}
              artistImage={data.images[0].url} 
              artistName={data.name}
            />)}
        </div>
      </div>
    </>
    
  )
}

export default TopArtists;