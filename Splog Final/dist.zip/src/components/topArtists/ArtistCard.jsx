const ArtistCard = (props) => {
  return (
    <div>
      <img className="aspect-square object-cover" src={props.artistImage} alt="Artist Picture" />
      <div className="bg-white p-2">
        <h4 className="truncate text-lg text-black font-bold">{props.artistName}</h4>
      </div>
    </div>
  )
}

export default ArtistCard;