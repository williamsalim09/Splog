const PlaylistCard = (props) => {
  return (
    <div>
      <img src={props.albumCover} alt="album cover" />
      <div>
        <p>{props.songTitle}</p>
        <p>{props.artistName}</p>
      </div>
    </div>
  )
}

export default PlaylistCard;