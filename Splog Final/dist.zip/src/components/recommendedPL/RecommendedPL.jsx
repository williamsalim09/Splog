import axios from "axios";
import { useEffect, useState } from "react";
import TimeFrameSelector from "../common/TimeFrameSelector";

import { getSeeds } from "../../utilities/reco";
import PlaylistCard from "./PlaylistCard";
import RecoBanner from "./RecoBanner";

const RecommendedPL = (props) => {
  const [recoSongs, setRecoSongs] = useState([])
  const [songSeeds, setSongSeeds] = useState("")
  const [token, setToken] = useState("")

  useEffect(() => {
    if (localStorage.getItem("accessToken")) {
      setToken(localStorage.getItem("accessToken"))
    }

    if (props.songData != 0) {
      setSongSeeds(getSeeds(props.songData.items))
      getRecoData();
    }
  }, [props])

  const getRecoData = () => {
    axios.get("https://api.spotify.com/v1/me/top/tracks?time_range=short_term&limit=3", {
      headers: {
        Authorization: "Bearer " + token,
      }
    })
    .then(response => {
      const seeds = getSeeds(response.data.items)
      return axios.get(`https://api.spotify.com/v1/recommendations?limit=10&seed_artists=${seeds}&min_popularity=70`, {
        headers: {
          Authorization: "Bearer " + token,
        }
      })
    })
    .then(response => {
      console.log(response.data.tracks)
      setRecoSongs(response.data.tracks)
    })
    .catch(error => {
      console.log(error)
    })
  }

  if (recoSongs.length == 0) {
    return (
      <div></div>
    )
  }

  return (
    <>
      <RecoBanner></RecoBanner>
      <div className="w-3/5 mx-auto pb-10">
        <div className="bg-amber-500 flex justify-between px-4">
            <p className="text-black text-3xl font-bold">Recommendations</p>
        </div>
        <p className="font-medium">Recommendations based on past 4 week's listening</p>
        <div className="grid grid-cols-5 gap-4">
          {recoSongs.map(data => 
            <PlaylistCard
              key={data.id}
              albumCover={data.album.images[0].url}
              songTitle={data.name}
              artistName={data.artists[0].name}
            />
          )}
        </div>
      </div>
    </>
  )
}

export default RecommendedPL;