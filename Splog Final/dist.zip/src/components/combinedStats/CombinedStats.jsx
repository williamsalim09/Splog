import { useEffect, useState } from "react";

import TimeFrameSelector from "../common/TimeFrameSelector";
import CombinedStatsBanner from "./CombinedStatsBanner";

const CombinedStats = (props) => {
  const [combinedData, setCombinedData] = useState([]);

  useEffect(() => {
    let combinedData = []

    combinedData.push(props.artistsData);
    combinedData.push(props.songsData);

    setCombinedData(combinedData)
  }, [props])

  const getShortTermData = (data) => {
    setCombinedData(data)
  }

  const getMediumTermData = (data) => {
    setCombinedData(data)
  }

  const getLongTermData = (data) => {
    setCombinedData(data)
  }

  if (combinedData.length === 0 || combinedData[0].items == undefined || combinedData[1].items == undefined || combinedData[0].items.length == 0 || combinedData[1].items.length == 0) {
    return (
      <div></div>
    )
  }

  console.log(combinedData)

  return (
    <>
      <CombinedStatsBanner></CombinedStatsBanner>
      <div className="w-3/5 mx-auto pb-10">
        <div className="bg-amber-500 flex justify-between px-4">
          <p className="text-black text-3xl font-bold">Combined Stats</p>
          <div className="flex text-black font-medium">
            <TimeFrameSelector termTitle={"Last Month"} term={"short"} type={"combined"} onGetShortTermData={getShortTermData}/>
            <TimeFrameSelector termTitle={"Last 6 Month"} term={"medium"} type={"combined"} onGetMediumTermData={getMediumTermData}/>
            <TimeFrameSelector termTitle={"All Time"} term={"long"} type={"combined"} onGetLongTermData={getLongTermData}/>
          </div>
        </div>
        <p className="text-neutral-300 py-1 font-medium">Your combined stats from the past 4 weeks</p>
        <div className="bg-gradient-to-b from-amber-500 to-white w-[30rem] h-[auto] mx-auto">
          <img className="p-5" src={combinedData[0].items[0].images[0].url} alt="artist portrait" />
          <div className="flex text-black px-5 pb-5">
            <div className="text-lg w-1/2">
              <h4 className="font-bold">Top Artists</h4>
              <ul className="font-semibold">
                <li><p>#1 {combinedData[0].items[0].name}</p></li>
                <li><p>#2 {combinedData[0].items[1].name}</p></li>
                <li><p>#3 {combinedData[0].items[2].name}</p></li>
                <li><p>#4 {combinedData[0].items[3].name}</p></li>
                <li><p>#5 {combinedData[0].items[4].name}</p></li>
              </ul>
            </div>
            <div className="text-lg w-1/2 truncate">
              <h4 className="font-bold">Top Songs</h4>
              <ul className="font-semibold">
                <li><p>#1 {combinedData[1].items[0].name}</p></li>
                <li><p>#2 {combinedData[1].items[1].name}</p></li>
                <li><p>#3 {combinedData[1].items[2].name}</p></li>
                <li><p>#4 {combinedData[1].items[3].name}</p></li>
                <li><p>#5 {combinedData[1].items[4].name}</p></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </>
    
  )
}

export default CombinedStats;